import pyodbc
import json
from decimal import Decimal
import re

# Step 1: SQL Server connection
conn = pyodbc.connect(
    'DRIVER={ODBC Driver 17 for SQL Server};'
    'SERVER=HM412S3\\SQLEXPRESS;'
    'DATABASE=postmigration;'  # Using source database to run EXCEPT/NOT EXISTS queries
    'Trusted_Connection=yes;'
)
cursor = conn.cursor()

# Step 2: Read SQL queries from Gemini output
with open("generated_queries.sql", "r", encoding="utf-8") as file:
    lines = file.readlines()

queries = []
current_query = ""

# Step 3: Parse queries
for line in lines:
    line = line.strip()
    if line == "":
        continue
    current_query += line + " "
    if line.endswith(";"):
        queries.append(current_query.strip().rstrip(";"))
        current_query = ""

# Step 4: Extract table info from queries (assumes format: database.schema.table)
def extract_table_info(query):
    match = re.findall(r"(postmigrationd?|dbo)\.(\w+)", query)
    source_table, target_table = "", ""
    src_schema, tgt_schema = "dbo", "dbo"

    for schema, table in match:
        if schema == "postmigration":
            source_table = table
        elif schema == "postmigrationd":
            target_table = table

    return {
        "SourceQuery": "",  # Optional: You can split or store separately
        "TargetQuery": "",
        "SrcSchemaName": "dbo",
        "DestSchemaName": "dbo",
        "SourceTable": source_table,
        "DestTableName": target_table
    }

# Step 5: Helper to convert Decimal rows to JSON
def convert_row(row, columns):
    return {
        column: float(value) if isinstance(value, Decimal) else value
        for column, value in zip(columns, row)
    }

# Step 6: Run queries and build result JSON
results = []

for i, query in enumerate(queries, 1):
    table_info = extract_table_info(query)
    result = {
        "QueryNumber": i,
        **table_info,
        "Status": "",
        "Data": []
    }

    try:
        cursor.execute(query)
        columns = [col[0] for col in cursor.description]
        rows = cursor.fetchall()

        if not rows:
            result["Status"] = "Pass"
        else:
            result["Status"] = "Fail"
            result["Data"] = [convert_row(row, columns) for row in rows]
    except Exception as e:
        result["Status"] = "Error"
        result["Data"] = {"error_message": str(e)}

    results.append(result)

# Step 7: Save final JSON result
with open("query_results.json", "w", encoding="utf-8") as f:
    json.dump(results, f, indent=2)

print(f"✅ Executed {len(results)} queries. Results saved to 'query_results.json'.")

# Step 8: Clean up
cursor.close()
conn.close()
