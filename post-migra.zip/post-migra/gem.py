import json
import urllib.request
import ssl
import re
import pyodbc
import time
from typing import List, Dict, Any
from pydantic import BaseModel, ValidationError, EmailStr

# Load metadata
with open("metadata_postmigration.json", "r") as f:
    source = json.load(f)

with open("metadata_postmigrationd.json", "r") as f:
    target = json.load(f)

def extract_table_names(metadata):
    if isinstance(metadata, dict) and "tables" in metadata:
        return [table["name"] for table in metadata["tables"] if "name" in table]
    elif isinstance(metadata, list):
        return [table["name"] for table in metadata if "name" in table]
    return []

source_tables = extract_table_names(source)
target_tables = extract_table_names(target)
table_names = sorted(set(source_tables + target_tables))
table_list = ", ".join(table_names)

url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent"
api_key = "AIzaSyBKiHYby_MTX11xJoczLtx0MPw0gDNFPyc"  # Insert your API key
context = ssl._create_unverified_context()

source_conn_str = "DRIVER={ODBC Driver 17 for SQL Server};SERVER=HM412S3\\SQLEXPRESS;DATABASE=postmigration;Trusted_Connection=yes;"
target_conn_str = "DRIVER={ODBC Driver 17 for SQL Server};SERVER=HM412S3\\SQLEXPRESS;DATABASE=postmigrationd;Trusted_Connection=yes;"

def execute_query(connection_string: str, query: str):
    try:
        with pyodbc.connect(connection_string) as conn:
            cursor = conn.cursor()
            cursor.execute(query)
            results = cursor.fetchall()
            return [tuple(row) for row in results]
    except Exception as e:
        return f"Error: {str(e)}"

def compare_results(src_result, tgt_result):
    if isinstance(src_result, str) or isinstance(tgt_result, str):
        return "Error in Execution"
    return "Match" if sorted(src_result) == sorted(tgt_result) else "Mismatch"

def call_gemini(prompt):
    payload = json.dumps({"contents": [{"parts": [{"text": prompt}]}]}).encode('utf-8')
    headers = {"Content-Type": "application/json"}
    req = urllib.request.Request(f"{url}?key={api_key}", data=payload, headers=headers, method='POST')
    with urllib.request.urlopen(req, context=context) as response:
        data = json.loads(response.read().decode())
        generated_text = data["candidates"][0]["content"]["parts"][0]["text"]
        clean_text = re.sub(r'^```json\\s*|\\s*```$', '', generated_text.strip())
        clean_text = re.sub(r'^```\\s*|\\s*```$', '', clean_text.strip())
        json_match = re.search(r'(\[[\s\S]*\])', clean_text)
        return json.loads(json_match.group(1)) if json_match else []

def validate_and_compare(queries):
    enriched_results = []
    for q in queries:
        src_query = q["SourceQuery"]
        tgt_query = q["TargetQuery"]

        src_result = execute_query(source_conn_str, src_query)
        tgt_result = execute_query(target_conn_str, tgt_query)

        comparison_status = compare_results(src_result, tgt_result)

        q["ComparisonResult"] = comparison_status
        q["SourceResultSample"] = src_result[:5] if not isinstance(src_result, str) else src_result
        q["TargetResultSample"] = tgt_result[:5] if not isinstance(tgt_result, str) else tgt_result

        enriched_results.append(q)
    return enriched_results

# Email regex validation
EMAIL_REGEX = re.compile(r"^[\w\.-]+@[\w\.-]+\\.\w+$")

def is_valid_email(email: str) -> bool:
    return bool(EMAIL_REGEX.match(email))

# Example table config for custom validations
validation_rules = {
    "email": "email_format",
    "age": ["avg", "min", "max"],
    "name": ["max_length", "null_count"]
}

# Gemini prompt generation
validation_types = [
    ("Row-level", [
        "Record Count Comparison - Compare the total number of records",
        "Primary Key Validation - Ensure primary keys match between source and target"
    ]),
    ("Column-level", [
        "Data Type Consistency",
        "Null Value Check",
        "Max String Length",
        "Email Regex Format Check",
        "Min/Max/Avg for numerics"
    ])
]

all_validation_results = []

for validation_type, checks in validation_types:
    prompt = f"""
    You are a senior data engineer validating data migration between two SQL Server databases:

    Below is the metadata of both databases in JSON format.
    Source DB: postmigration
    Target DB: postmigrationd

    Table names: {table_list}

    Validation types:
    {'\\n'.join(checks)}

    Return JSON array only. Each object must include:
    {{
      "SourceQuery": "...",
      "TargetQuery": "...",
      "ValidationType": "{validation_type}"
    }}

    Avoid including table/column names as keys. Embed them in the SQL queries.
    """
    print(f"Calling Gemini for {validation_type} validation...")
    try:
        result = call_gemini(prompt)
        validated_result = validate_and_compare(result)
        all_validation_results.extend(validated_result)
        time.sleep(2)
    except Exception as e:
        print(f"Error in {validation_type} validation: {e}")

with open("final_validation_results.json", "w") as f:
    json.dump(all_validation_results, f, indent=2)

print("✅ All validations completed and saved to 'final_validation_results.json'")