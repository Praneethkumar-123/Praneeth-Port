import pyodbc
import json

def fun(database):
    conn = pyodbc.connect('Driver={SQL Server};'
                          f'Server=HM412S3\\SQLEXPRESS;'
                          f'Database={database};'
                          'Trusted_Connection=yes;')
    cursor = conn.cursor()

    # Fetch column metadata with schema
    query = """
        SELECT 
            table_schema, table_name, column_name, data_type,
            is_nullable, character_maximum_length
        FROM Information_Schema.columns
    """
    cursor.execute(query)
    column_metadata = cursor.fetchall()

    # Fetch primary keys with schema
    pk_query = """
        SELECT 
            TABLE_SCHEMA, TABLE_NAME, COLUMN_NAME 
        FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
        WHERE CONSTRAINT_NAME LIKE 'PK%'
    """
    cursor.execute(pk_query)
    primary_keys = cursor.fetchall()

    # Fetch foreign keys with schema
    fk_query = """
        SELECT 
            fk.TABLE_SCHEMA, fk.TABLE_NAME, fk.COLUMN_NAME, 
            pk.TABLE_SCHEMA AS REF_SCHEMA, pk.TABLE_NAME AS REFERENCED_TABLE, pk.COLUMN_NAME AS REFERENCED_COLUMN
        FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE fk
        JOIN INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS rc 
            ON fk.CONSTRAINT_NAME = rc.CONSTRAINT_NAME
        JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE pk 
            ON rc.UNIQUE_CONSTRAINT_NAME = pk.CONSTRAINT_NAME
    """
    cursor.execute(fk_query)
    foreign_keys = cursor.fetchall()

    # Build metadata dictionary
    metadata = {}

    # Process columns
    for row in column_metadata:
        schema, table, column, datatype, nullable, char_max = row
        full_table_name = f"{schema}.{table}"
        if full_table_name not in metadata:
            metadata[full_table_name] = {
                "schema": schema,
                "table": table,
                "columns": []
            }
        metadata[full_table_name]["columns"].append({
            "name": column,
            "type": datatype,
            "nullable": nullable,
            "max_length": char_max
        })

    # Process primary keys
    for row in primary_keys:
        schema, table, column = row
        full_table_name = f"{schema}.{table}"
        if full_table_name in metadata:
            if "primary_keys" not in metadata[full_table_name]:
                metadata[full_table_name]["primary_keys"] = []
            metadata[full_table_name]["primary_keys"].append(column)

    # Process foreign keys
    for row in foreign_keys:
        schema, table, column, ref_schema, ref_table, ref_column = row
        full_table_name = f"{schema}.{table}"
        if full_table_name in metadata:
            if "foreign_keys" not in metadata[full_table_name]:
                metadata[full_table_name]["foreign_keys"] = []
            metadata[full_table_name]["foreign_keys"].append({
                "column": column,
                "references": {
                    "schema": ref_schema,
                    "table": ref_table,
                    "column": ref_column
                }
            })

    # Save metadata to JSON file
    filename = f"metadata_{database}.json"
    with open(filename, "w") as json_file:
        json.dump(metadata, json_file, indent=4)

    print(f"Metadata saved to {filename}")
    conn.close()

# Run the function
database = input("Enter the database name: ")
fun(database)
