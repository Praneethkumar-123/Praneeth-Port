import pyodbc
import json

def fun(database):
    conn = pyodbc.connect('Driver={SQL Server};'
                        f'Server=HM412S3\\SQLEXPRESS;'
                        f'Database={database};'
                        'Trusted_Connection=yes;')
    cursor = conn.cursor()
    
    # Execute tables and columns
    query = """select 
                table_name, column_name, data_type,
                is_nullable, character_maximum_length
             from Information_Schema.columns
             """
    
    cursor.execute(query)
    column_metadata = cursor.fetchall()
    print("COLUMN_METADATA")
    '''for row in column_metadata:
        print(row)'''
    
    '''for row in rows:
        print(row)*/'''
    
    #extract primary key
    q="""select
              TABLE_NAME, COLUMN_NAME 
           FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
           WHERE CONSTRAINT_NAME LIKE 'PK%'
        """
    cursor.execute(q)
    primary_keys=cursor.fetchall()
    print("PRIMARY_KEYS")
    '''for row in primary_keys:
        print(row)'''
    
    #extract foreign keys
    query="""
        SELECT 
            fk.TABLE_NAME, fk.COLUMN_NAME, pk.TABLE_NAME AS REFERENCED_TABLE, pk.COLUMN_NAME AS REFERENCED_COLUMN
        FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE fk
        JOIN INFORMATION_SCHEMA.REFERENTIAL_CONSTRAINTS rc ON fk.CONSTRAINT_NAME = rc.CONSTRAINT_NAME
        JOIN INFORMATION_SCHEMA.KEY_COLUMN_USAGE pk ON rc.UNIQUE_CONSTRAINT_NAME = pk.CONSTRAINT_NAME
        """
    
    cursor.execute(query)
    foreign_keys=cursor.fetchall()
    print("FOREIGN_KEYS")
    
    '''for row in foreign_keys:
        print(row)'''
    
    metadata={}
    for row in column_metadata:
        table, column, datatype, nullable, char_max=row
        if table not in metadata:
            metadata[table]={"columns":[]}
        
        metadata[table]['columns'].append({
            "name": column,
            "type": datatype,
            "nullable": nullable,
            "max_length": char_max
        })
    
    for row in primary_keys:
        table, column = row
        if table in metadata:
            if "primary_keys" not in metadata[table]:
                metadata[table]["primary_keys"] = []
            metadata[table]["primary_keys"].append(column)
    
    for row in foreign_keys:
        table, column, ref_table, ref_column = row
        if table in metadata:
            if "foreign_keys" not in metadata[table]:
                metadata[table]["foreign_keys"] = []
            metadata[table]["foreign_keys"].append({
                "column": column,
                "references": {
                    "table": ref_table,
                    "column": ref_column
                }
            })
    
    # Generate filename based on database name
    filename = f"metadata_{database}.json"
    with open(filename, "w") as json_file:
        json.dump(metadata, json_file, indent=4)
    
    print(f"Metadata saved to {filename}")
    conn.close()

database = input("Enter the database name: ")
fun(database)