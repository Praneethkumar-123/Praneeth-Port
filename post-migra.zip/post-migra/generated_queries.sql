```sql
SELECT COUNT(*) FROM postmigration.dbo.customer EXCEPT SELECT COUNT(*) FROM postmigrationd.dbo.customer;
SELECT COUNT(*) FROM postmigration.dbo.orders EXCEPT SELECT COUNT(*) FROM postmigrationd.dbo.orders;

```
