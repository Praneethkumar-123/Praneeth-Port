import json
import urllib.request
import ssl
import re
import time

# Load source and target metadata
with open("metadata_postmigration.json", "r") as f:
    source = json.load(f)

with open("metadata_postmigrationd.json", "r") as f:
    target = json.load(f)

# Extract table names from both source and target metadata
def extract_table_names(metadata):
    if isinstance(metadata, dict) and "tables" in metadata:
        return [table["name"] for table in metadata["tables"] if "name" in table]
    elif isinstance(metadata, list):
        return [table["name"] for table in metadata if "name" in table]
    return []

source_tables = extract_table_names(source)
target_tables = extract_table_names(target)

# Combine and deduplicate table names
table_names = sorted(set(source_tables + target_tables))
table_list = ",".join(table_names)

# Gemini API
url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent"
api_key = "AIzaSyBKiHYby_MTX11xJoczLtx0MPw0gDNFPyc"  # Replace with your Gemini API key
context = ssl._create_unverified_context()

# Validation types and descriptions
validation_types = {
    "Row-level": [
        "1. Record Count Comparison - Compare the total number of records",
        "2. Primary Key Validation - Ensure primary keys match between source and target"
    ],
    "Column-level": [
        "1. Data Type Consistency - Verify data types match for each column",
        "2. Null Value Check - Compare null values in each column"
    ],
    "Table-level": [
        "1. Schema Comparison - Compare table structure",
        "2. Foreign Key Validation - Verify foreign key relationships, including:\n   - Check if foreign keys in the customer table correctly reference their parent tables\n   - Verify referential integrity between source and target\n   - Detect orphaned records or mismatched relationships"
    ]
}

# Function to call Gemini API
def call_gemini(prompt_text):
    payload = json.dumps({"contents": [{"parts": [{"text": prompt_text}]}]}).encode('utf-8')
    headers = {"Content-Type": "application/json"}
    req = urllib.request.Request(f"{url}?key={api_key}", data=payload, headers=headers, method='POST')

    try:
        with urllib.request.urlopen(req, context=context) as response:
            data = json.loads(response.read().decode())
            generated_text = data["candidates"][0]["content"]["parts"][0]["text"]

            # Clean and extract only JSON part
            clean_text = re.sub(r'^```json\s*|\s*```$', '', generated_text.strip())
            clean_text = re.sub(r'^```\s*|\s*```$', '', clean_text.strip())
            match = re.search(r'(\[[\s\S]*\])', clean_text)
            if match:
                clean_text = match.group(1)
            return json.loads(clean_text)
    except Exception as e:
        print(f"Error: {e}")
        return []

# Collect all results
all_validation_results = []

# Loop through each validation type and generate SQL queries using Gemini
for validation_type, queries in validation_types.items():
    print(f"🔍 Generating queries for: {validation_type}")

    validation_query_text = "\n".join(queries)

    prompt = f"""
You are a senior data engineer validating data migration between two SQL Server databases.

Below is the metadata of both databases in JSON format.
Source database: postmigration
Destination database: postmigrationd

Source metadata:
{json.dumps(source, indent=2)}

Target metadata:
{json.dumps(target, indent=2)}

Table names: {table_list}

Generate T-SQL queries ONLY for the following **{validation_type} validations** across ALL listed tables:

{validation_query_text}

Important JSON structure:
- Return a valid JSON array `[ ... ]`, where each object represents one validation query.
- Each query object should contain:
{{
  "SourceQuery": "...",
  "TargetQuery": "...",
  "SrcDatabaseName": "postmigration",
  "DestDatabaseName": "postmigrationd",
  "SrcSchemaName": "dbo",
  "DestSchemaName": "dbo",
  "ValidationType": "{validation_type}"
}}

For Column-level validation ONLY, also include:
- "ColumnName": "name_of_the_column"
Do NOT include explanation or formatting (like ```json). Only return pure JSON.
"""

    result = call_gemini(prompt)
    all_validation_results.extend(result)
    time.sleep(1)  # Optional: prevent request throttling

# Save output to file
output_file = "validation_queries_by_type.json"
with open(output_file, "w") as f:
    json.dump(all_validation_results, f, indent=2)

print(f"✅ All validation queries saved to {output_file}")
