import json
import pyodbc
from datetime import datetime

# Load validation queries
with open("validation_queries.json", "r") as f:
    validation_queries = json.load(f)

# DB connection info — replace these with your own
source_conn_str = "DRIVER={SQL Server};SERVER=HM412S3\\SQLEXPRESS;DATABASE=postmigration;Trusted_Connection=yes;"
target_conn_str = "DRIVER={SQL Server};SERVER=HM412S3\\SQLEXPRESS;DATABASE=postmigrationd;Trusted_Connection=yes;"

# Create connections
src_conn = pyodbc.connect(source_conn_str)
tgt_conn = pyodbc.connect(target_conn_str)

src_cursor = src_conn.cursor()
tgt_cursor = tgt_conn.cursor()

# Function to execute query and return result
def execute_query(cursor, query):
    try:
        cursor.execute(query)
        rows = cursor.fetchall()
        return rows
    except Exception as e:
        return f"Error: {str(e)}"

# To store results
results_summary = []

for i, query_obj in enumerate(validation_queries, start=1):
    print(f"\n▶️ Running Validation {i}: {query_obj.get('ValidationType')}")

    src_query = query_obj["SourceQuery"]
    tgt_query = query_obj["TargetQuery"]
    val_type = query_obj.get("ValidationType")
    column = query_obj.get("ColumnName", "")
    table = src_query.split("FROM")[1].strip().split()[0] if "FROM" in src_query else "Unknown"

    src_result = execute_query(src_cursor, src_query)
    tgt_result = execute_query(tgt_cursor, tgt_query)

    match = src_result == tgt_result
    result_entry = {
        "ValidationIndex": i,
        "Table": table,
        "ValidationType": val_type,
        "Column": column,
        "SourceResult": str(src_result),
        "TargetResult": str(tgt_result),
        "Match": match,
        "Timestamp": str(datetime.now())
    }

    results_summary.append(result_entry)

# Save results to file
with open("comparison_results.json", "w") as f:
    json.dump(results_summary, f, indent=2)

print("\n✅ Comparison complete. Results saved to comparison_results.json")
