import json

# Load Source and Destination Metadata
with open("metadatasrc.json", "r") as src_file:
    source_metadata = json.load(src_file)

with open("metadatadest.json", "r") as dest_file:
    destination_metadata = json.load(dest_file)

# Initialize a dictionary to store differences
differences = {}

# Compare Tables
source_tables = set(source_metadata.keys())
destination_tables = set(destination_metadata.keys())

missing_in_dest = source_tables - destination_tables
extra_in_dest = destination_tables - source_tables

if missing_in_dest:
    differences["missing_tables_in_destination"] = list(missing_in_dest)
if extra_in_dest:
    differences["extra_tables_in_destination"] = list(extra_in_dest)

# Compare Columns, Data Types, and Constraints
for table in source_tables & destination_tables:
    src_columns = {col["name"]: col for col in source_metadata[table]["columns"]}
    dest_columns = {col["name"]: col for col in destination_metadata[table]["columns"]}

    missing_columns = set(src_columns.keys()) - set(dest_columns.keys())
    extra_columns = set(dest_columns.keys()) - set(src_columns.keys())

    column_differences = []
    for col_name in src_columns.keys() & dest_columns.keys():
        src_col = src_columns[col_name]
        dest_col = dest_columns[col_name]

        col_diff = {}
        if src_col["type"] != dest_col["type"]:
            col_diff["data_type_mismatch"] = {"source": src_col["type"], "destination": dest_col["type"]}
        if src_col["nullable"] != dest_col["nullable"]:
            col_diff["nullability_mismatch"] = {"source": src_col["nullable"], "destination": dest_col["nullable"]}
        if src_col["max_length"] != dest_col["max_length"]:
            col_diff["max_length_mismatch"] = {"source": src_col["max_length"], "destination": dest_col["max_length"]}

        if col_diff:
            column_differences.append({col_name: col_diff})

    if missing_columns or extra_columns or column_differences:
        differences[table] = {
            "missing_columns": list(missing_columns),
            "extra_columns": list(extra_columns),
            "column_differences": column_differences
        }

# Compare Primary Keys
for table in source_tables & destination_tables:
    src_pks = set(source_metadata[table].get("primary_keys", []))
    dest_pks = set(destination_metadata[table].get("primary_keys", []))

    if src_pks != dest_pks:
        differences.setdefault(table, {})["primary_key_mismatch"] = {
            "source": list(src_pks),
            "destination": list(dest_pks)
        }

# Compare Foreign Keys
for table in source_tables & destination_tables:
    src_fks = {fk["column"]: fk["references"] for fk in source_metadata[table].get("foreign_keys", [])}
    dest_fks = {fk["column"]: fk["references"] for fk in destination_metadata[table].get("foreign_keys", [])}

    fk_diff = {}
    for column in src_fks.keys() | dest_fks.keys():
        if src_fks.get(column) != dest_fks.get(column):
            fk_diff[column] = {"source": src_fks.get(column), "destination": dest_fks.get(column)}

    if fk_diff:
        differences.setdefault(table, {})["foreign_key_mismatch"] = fk_diff

# Print or Save Differences
if differences:
    with open("metadata_differences.json", "w") as diff_file:
        json.dump(differences, diff_file, indent=4)

    print("Differences found! Check 'metadata_differences.json' for details.")
else:
    print("No differences found. Metadata is identical.")
