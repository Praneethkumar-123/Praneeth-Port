import pyodbc
import json
from decimal import Decimal
import re

# Step 1: SQL Server connection
conn = pyodbc.connect(
    'DRIVER={ODBC Driver 17 for SQL Server};'
    'SERVER=HM412S3\\SQLEXPRESS;'
    'DATABASE=postmigration;'
    'Trusted_Connection=yes;'
)
cursor = conn.cursor()

# Step 2: Read SQL queries from file
with open("generated_queries.sql", "r") as file:
    lines = file.readlines()

queries = []
current_query = ""
metadata = {}

# Step 3: Parse queries with metadata
for line in lines:
    line = line.strip()
    if line.startswith("--"):
        match = re.match(r"--\s*(\w+):\s*(.*)", line)
        if match:
            key = match.group(1)
            value = match.group(2)
            metadata[key] = value
        continue
    if line == "":
        continue

    current_query += line + " "
    if line.endswith(";"):
        queries.append({
            "query": current_query.strip().rstrip(";"),
            "metadata": metadata.copy()
        })
        current_query = ""
        metadata = {}

# Helper to convert row with decimals
def convert_row(row, columns):
    return {
        column: float(value) if isinstance(value, Decimal) else value
        for column, value in zip(columns, row)
    }

# Helper to extract db.schema.table from query
def extract_db_schema_table(sql_query):
    return re.findall(r"FROM\s+([\w]+)\.([\w]+)\.([\w]+)", sql_query, re.IGNORECASE)

# Step 4: Execute queries and format results
results_json = []

for i, item in enumerate(queries, 1):
    query = item["query"]
    meta = item["metadata"]

    db_info = extract_db_schema_table(query)
    src_db, src_schema, src_table = db_info[0] if len(db_info) > 0 else ("", "", "")
    tgt_db, tgt_schema, tgt_table = db_info[1] if len(db_info) > 1 else ("", "", "")

    result_entry = {
        "QueryNumber": i,
        "SourceQuery": f"SELECT COUNT(*) FROM {src_db}.{src_schema}.{src_table}",
        "TargetQuery": f"SELECT COUNT(*) FROM {tgt_db}.{tgt_schema}.{tgt_table}",
        "SrcDatabaseName": src_db,
        "DestDatabaseName": tgt_db,
        "SrcSchemaName": src_schema,
        "DestSchemaName": tgt_schema,
        "SourceTable": src_table,
        "DestTableName": tgt_table
    }

    '''
    try:
        cursor.execute(query)
        columns = [col[0] for col in cursor.description]
        rows = cursor.fetchall()

        if not rows:
            result_entry["Status"] = "Pass"
        else:
            result_entry["Status"] = "Fail"
            result_entry["Data"] = [convert_row(row, columns) for row in rows]

    except Exception as e:
        result_entry["Status"] = "Error"
        result_entry["Data"] = {"error_message": str(e)}
    '''

    results_json.append(result_entry)

# Step 5: Write JSON output to a file
with open("result.json", "w") as json_file:
    json.dump(results_json, json_file, indent=2)
print("Results saved to result.json")

# Step 6: Cleanup
cursor.close()
conn.close()
